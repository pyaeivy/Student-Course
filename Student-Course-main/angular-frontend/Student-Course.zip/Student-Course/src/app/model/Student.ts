export type Student = {
    id?: number;
    name: string;
    email:string;
    phone:string;
    address:string;
    gender?: string;
    status?:string;
    
}