export type Role = {
    id: number;
    roleName: string;
};