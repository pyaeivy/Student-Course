export type Course = {
    id?: number;
    courseName: string;
    instructor: string;
    price : number;
    courseImg: string;
    description: string;
}